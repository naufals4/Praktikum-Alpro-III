/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package praktikumsaya;


public class PraktikumSaya {
public int average (int a,int b){
    return ((a+b)/2);

}
public double average(double a,double b){
    return ((a+b)/2);

}
public int average (int a,int b, int c){
    return ((a+b+c)/3);
}
}

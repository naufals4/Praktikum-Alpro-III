/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package praktikumsaya;


public class Kecebong extends Katak {

    double panjangEkor;

    public Kecebong(int umur, String nama, double panjangEkor) {
        super(umur, nama);
        this.umur = umur;
        this.nama = nama;
        this.panjangEkor = panjangEkor;

    }

    public double getPanjangEkor() {
        return panjangEkor;
    }

    public void setPanjangEkor(double panjangEkor) {
        this.panjangEkor = panjangEkor;
    }

    public int getUmur() {
        return umur;
    }

    public void setUmur(int umur) {
        this.umur = umur;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }
    

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package praktikumsaya;


public class TesTugas2 {
    public static void main(String[] args) {
        Katak objek1 = new Katak(5, "Froggy");
        Kecebong objek2 = new Kecebong(2, "junior Frog", 10);
        System.out.println("Obyek \t Umur \t nama \t \t panjang ekor \t cara bergerak");
        System.out.println("=================================================================");
        System.out.println("O1\t|" + objek1.getUmur() + "\t|" + objek1.getNama() + "\t \t| \t \t|" + objek1.caraBergerak());
        System.out.println("=================================================================");
        System.out.println("O2\t|" + objek2.getUmur() + "\t|" + objek2.getNama() + "\t|" + objek2.getPanjangEkor() + "\t \t|" + objek2.caraBergerak());

    }

}

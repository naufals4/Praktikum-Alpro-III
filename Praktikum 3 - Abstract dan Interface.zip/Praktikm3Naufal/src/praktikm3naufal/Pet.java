package praktikm3naufal;

public interface Pet {
    public String getNama();
    public void setNama(String nama);
    public void play();
}

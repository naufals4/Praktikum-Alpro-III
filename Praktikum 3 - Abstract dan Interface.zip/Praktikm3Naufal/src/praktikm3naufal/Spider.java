package praktikm3naufal;
public class Spider extends Animal  {
    public Spider(){
        super(8);
    }
    
    @Override
    public void eat(){
        System.out.println("Saya suka makan serangga dan sejenisnya");
    }
}

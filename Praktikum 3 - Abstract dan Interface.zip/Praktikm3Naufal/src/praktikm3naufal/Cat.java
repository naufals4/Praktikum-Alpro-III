package praktikm3naufal;

public class Cat extends Animal implements Pet {
    String nama;
    
    public Cat(String nama) {
        super(4);
        this.nama=nama;
    }
    
    public Cat(){
        this("");
    }
    
    @Override
    public String getNama(){
        return nama;
    }
    @Override
    public void setNama(String nama){
        this.nama=nama;
    }
    @Override
    public void play(){
        System.out.println(nama +  " Playing mouse catching");
    }
    
    @Override
    public void eat(){
        System.out.println("Suka memakan Tikus");
    }
}

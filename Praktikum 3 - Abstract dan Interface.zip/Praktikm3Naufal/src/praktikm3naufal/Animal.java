package praktikm3naufal;

public abstract class Animal {
    protected int legs;
    
    protected Animal(int legs){
        this.legs=legs;
    }
    
    public abstract void eat();
    
    public void concrete(){
        System.out.println("Hewan ini berjalan dengan " + legs + "kaki");
    }
}

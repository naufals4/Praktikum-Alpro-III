package praktikm3naufal;

public class Fish extends Animal implements Pet {
    private String nama;
    
    public Fish(){
        super(0);
    }
    
    @Override
    public void eat(){
        System.out.println("Suka makan Ikan lainnya");
    }
    
    @Override
    public void concrete(){
        super.concrete();
        System.out.println("Tidak berjalan denga kaki melainkan berenang");
    }
    
    @Override
    public String getNama(){
        return nama;
    }
    @Override
    public void setNama(String nama){
        this.nama=nama;
    }
    @Override
    public void play(){
        System.out.println("saya suka mencari ikan");
    }
}
